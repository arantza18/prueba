# Data Quality Dashboard (Vercel + Python + PostgreSQL/Neon)

## Ejecutar
```bash
npm i -g vercel
vercel dev
```
Defina `DATABASE_URL` (Neon) en Vercel y/o en local (.env).

## Conectar a Neon
1) Cree el proyecto en Neon y copie el **connection string (pooled)**:
   `postgresql://USER:PASS@POOLER-ENDPOINT.neon.tech/DBNAME?sslmode=require`
2) Vercel → Project Settings → Environment Variables → `DATABASE_URL`.
3) Local: copie `.env.example` a `.env` y pegue su cadena.

## Datos de prueba
- `scripts/seed.sql` (ejecútelo en el editor SQL de Neon o con `psql`).
- o `python scripts/seed.py` (usa `DATABASE_URL`).
